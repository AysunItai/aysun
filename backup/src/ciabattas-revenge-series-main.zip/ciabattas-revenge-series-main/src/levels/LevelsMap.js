import DemoLevel1 from "./DemoLevel1";
import DemoLevel2 from "./DemoLevel2";

const Levels = {
  DemoLevel1: DemoLevel1,
  DemoLevel2: DemoLevel2,
};

export default Levels;
