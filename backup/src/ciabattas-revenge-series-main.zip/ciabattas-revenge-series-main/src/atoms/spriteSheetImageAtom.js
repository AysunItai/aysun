import { atom } from "recoil";

export const spriteSheetImageAtom = atom({
  key: "spriteSheetImageAtom",
  default: null,
});
