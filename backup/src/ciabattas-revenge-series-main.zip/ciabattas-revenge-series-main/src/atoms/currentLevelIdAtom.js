import { atom } from "recoil";

export const currentLevelIdAtom = atom({
  key: "currentLevelIdAtom",
  default: "DemoLevel1",
});
